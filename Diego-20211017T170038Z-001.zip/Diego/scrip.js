var divs = document.getElementsByClassName("btn-group")

for(i=0,i<divs.length,++){
    document.divs(i).style.display="none"
}

